/**
 * NOETICA v2 — Main Application
 * ─────────────────────────────
 * Single-file vanilla JS app
 * API key: .env only  |  Wallet: required for AI
 */

import { Cfg }            from './utils/config.js'
import { encrypt, decrypt, genVaultKey, obfuscate } from './utils/crypto.js'
import { connectWallet, isConnected, getAddress, shortAddr, claimOnChain, getNOETBalance, mockTxHash } from './utils/wallet.js'
import { sendToAI, getInsight, detectCrisis } from './utils/ai.js'

// ═══════════════════════════════════════════
// STATE
// ═══════════════════════════════════════════
const S = {
  name:'', vaultKey:'', vault:null,
  messages:[], moods:[], entries:[],
  streak:0, bestStreak:0,
  noet:0, totalEarned:0, transactions:[],
  journaledToday:false, todayMood:null,
  selMood:null, selTags:[], isTyping:false,
  walletAddr: null,
  tab: 'chat',
  PROMPTS:[
    'What moment today made you feel most like yourself?',
    "What are you carrying right now that you haven't said out loud?",
    'If your emotions were weather today — what is the forecast?',
    'What would you tell a dear friend who felt exactly as you do now?',
    'Where in your body do you feel today\'s stress or calm?',
    'What small thing brought unexpected comfort recently?',
    'What does your ideal version of tomorrow look like?',
    'What are you grateful for in this exact moment?',
    'What emotion are you trying not to feel, and why?',
    'If today had a color or texture, what would it be?',
  ],
  get uMsgs() { return this.messages.filter(m=>m.role==='user').length }
}

// ═══════════════════════════════════════════
// VAULT / STORAGE
// ═══════════════════════════════════════════
async function saveVault() {
  if (!S.vaultKey) return
  const data = {
    name:S.name, messages:S.messages.slice(-40), moods:S.moods,
    entries:S.entries, streak:S.streak, bestStreak:S.bestStreak,
    noet:S.noet, totalEarned:S.totalEarned, transactions:S.transactions.slice(0,30),
    journaledToday:S.journaledToday
  }
  localStorage.setItem('noetica_v', await encrypt(JSON.stringify(data), S.vaultKey))
}

async function loadVault(key) {
  const raw = localStorage.getItem('noetica_v')
  if (!raw) throw new Error('No vault found')
  const data = JSON.parse(await decrypt(raw, key))
  S.vaultKey=key; S.name=data.name||''
  S.messages=data.messages||[]; S.moods=data.moods||[]
  S.entries=data.entries||[]; S.streak=data.streak||0
  S.bestStreak=data.bestStreak||0; S.noet=data.noet||0
  S.totalEarned=data.totalEarned||0; S.transactions=data.transactions||[]
  S.journaledToday = S.entries.some(e=>new Date(e.ts).toDateString()===new Date().toDateString())
}

// ═══════════════════════════════════════════
// RENDER ENGINE — inject full CSS+HTML to #app
// ═══════════════════════════════════════════
function mount() {
  document.getElementById('app').innerHTML = `
<style>
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{height:100%;font-size:16px;-webkit-font-smoothing:antialiased}
body{background:#030305;color:#fff;font-family:'DM Sans',system-ui,sans-serif;min-height:100vh;overflow:hidden}
:root{
  --void:#030305;--abyss:#06060a;--deep:#09090f;--surface:#0e0e18;
  --raised:#141420;--lift:#1a1a2a;--card:#1f1f2e;
  --b0:rgba(255,255,255,.03);--b1:rgba(255,255,255,.07);
  --b2:rgba(255,255,255,.12);--b3:rgba(255,255,255,.20);
  --s0:#2a2a3c;--s1:#444458;--s2:#666678;--s3:#88889a;
  --s4:#aaaabc;--s5:#ccccda;--s6:#e4e4f0;
  --teal:#00e5c8;--teal2:rgba(0,229,200,.1);
  --gold:rgba(255,210,80,.7);
  --fd:'Cormorant Garamond',Georgia,serif;
  --fb:'DM Sans',system-ui,sans-serif;
  --fm:'DM Mono',monospace;
  --r:10px;--rl:16px;--rxl:22px;
}
::-webkit-scrollbar{width:2px}
::-webkit-scrollbar-thumb{background:rgba(255,255,255,.08);border-radius:1px}
::selection{background:rgba(0,229,200,.2)}

/* ── BACKGROUND ── */
#bg{position:fixed;inset:0;z-index:0;overflow:hidden;pointer-events:none}
#bg::before{
  content:'';position:absolute;inset:-80%;
  background-image:linear-gradient(rgba(255,255,255,.012) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.012) 1px,transparent 1px);
  background-size:64px 64px;
  transform:perspective(500px) rotateX(22deg);
  transform-origin:50% 0%;
  animation:gridScroll 22s linear infinite;
}
@keyframes gridScroll{0%{background-position:0 0}100%{background-position:0 64px}}
#bg::after{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 80% 55% at 50% 100%,transparent 40%,var(--void) 100%)}
.orb{position:absolute;border-radius:50%;filter:blur(110px);animation:orbDrift ease-in-out infinite alternate}
.orb1{width:700px;height:700px;top:-280px;left:50%;transform:translateX(-50%);background:radial-gradient(circle,rgba(255,255,255,.032),transparent 65%);animation-duration:18s}
.orb2{width:500px;height:500px;bottom:-150px;right:-120px;background:radial-gradient(circle,rgba(0,229,200,.05),transparent 65%);animation-duration:13s;animation-delay:-5s}
.orb3{width:380px;height:380px;top:35%;left:-100px;background:radial-gradient(circle,rgba(110,110,200,.038),transparent 65%);animation-duration:22s;animation-delay:-9s}
@keyframes orbDrift{0%{transform:translate(0,0) scale(1)}50%{transform:translate(18px,-14px) scale(1.04)}100%{transform:translate(-14px,9px) scale(.97)}}
#nc{position:absolute;inset:0;opacity:.55}
.scan{position:absolute;left:0;right:0;height:160px;background:linear-gradient(to bottom,transparent,rgba(0,229,200,.022),transparent);animation:scanLine 10s linear infinite}
@keyframes scanLine{0%{top:-160px}100%{top:100vh}}
.grain{position:absolute;inset:0;opacity:.018;mix-blend-mode:overlay;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
  background-size:180px 180px}

/* ── SCREENS ── */
.screen{position:fixed;inset:0;display:flex;flex-direction:column;z-index:10;transition:opacity .5s,transform .5s}
.screen.out{opacity:0;transform:translateY(14px);pointer-events:none}
.scenter{position:relative;z-index:5;display:flex;flex-direction:column;align-items:center;justify-content:center;flex:1;padding:20px;text-align:center}

/* ── LANDING ── */
.logo-wrap{width:96px;height:96px;margin:0 auto 34px;position:relative}
.lring{position:absolute;inset:0;border-radius:50%;border:1px solid rgba(255,255,255,.09);animation:rBreath 3.5s ease-in-out infinite}
.lring:nth-child(2){inset:14px;border-color:rgba(255,255,255,.06);animation-delay:.9s}
.lring:nth-child(3){inset:28px;border-color:rgba(0,229,200,.18);animation-delay:1.8s}
.lcore{position:absolute;inset:40px;border-radius:50%;background:linear-gradient(135deg,rgba(255,255,255,.1),rgba(0,229,200,.06));border:1px solid rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;font-family:var(--fd);font-size:15px;color:rgba(255,255,255,.7);box-shadow:0 0 30px rgba(0,229,200,.08),inset 0 1px 0 rgba(255,255,255,.18)}
@keyframes rBreath{0%,100%{transform:scale(1);opacity:.5}50%{transform:scale(1.05);opacity:1}}

.eyebrow{display:inline-flex;align-items:center;gap:8px;padding:6px 18px;border-radius:40px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.07);font-family:var(--fm);font-size:10px;color:var(--s3);letter-spacing:.14em;text-transform:uppercase;margin-bottom:22px}
.pdot{width:5px;height:5px;border-radius:50%;background:var(--teal);box-shadow:0 0 8px var(--teal);animation:blink 2s ease-in-out infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.2}}

.land-h1{font-family:var(--fd);font-size:clamp(58px,11vw,108px);font-weight:300;letter-spacing:-.025em;line-height:.9;color:#fff;margin-bottom:12px}
.land-h1 em{font-style:italic;background:linear-gradient(160deg,#fff 0%,rgba(255,255,255,.45) 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.land-tag{font-family:var(--fd);font-style:italic;font-size:clamp(14px,2.2vw,18px);font-weight:300;color:var(--s2);letter-spacing:.06em;margin-bottom:28px}
.land-desc{font-size:13px;color:var(--s1);line-height:1.9;max-width:400px;margin:0 auto 44px}
.land-btns{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-bottom:50px}
.trust-row{display:flex;flex-wrap:wrap;gap:7px;justify-content:center}
.tpill{font-family:var(--fm);font-size:10px;color:var(--s0);letter-spacing:.1em;padding:5px 13px;border-radius:20px;background:rgba(255,255,255,.018);border:1px solid rgba(255,255,255,.045)}

.enter-hint{position:absolute;bottom:28px;left:50%;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:8px;color:var(--s0);font-family:var(--fm);font-size:9px;letter-spacing:.14em;text-transform:uppercase;cursor:pointer;z-index:5;animation:hFloat 3s ease-in-out infinite}
.enter-line{width:1px;height:38px;background:linear-gradient(to bottom,transparent,var(--s0),transparent);animation:lDraw 2.4s ease-in-out infinite}
@keyframes hFloat{0%,100%{transform:translateX(-50%) translateY(0)}50%{transform:translateX(-50%) translateY(7px)}}
@keyframes lDraw{0%{transform:scaleY(0);transform-origin:top}45%{transform:scaleY(1);transform-origin:top}55%{transform-origin:bottom}100%{transform:scaleY(0);transform-origin:bottom}}

/* ── BUTTONS ── */
.btn{display:inline-flex;align-items:center;gap:8px;padding:13px 30px;border-radius:40px;font-family:var(--fb);font-size:13px;font-weight:500;border:none;cursor:pointer;transition:all .25s;letter-spacing:.01em;white-space:nowrap}
.btn:disabled{opacity:.35;cursor:not-allowed}
.btn-w{background:#fff;color:var(--void);font-weight:600;box-shadow:0 4px 24px rgba(255,255,255,.1)}
.btn-w:not(:disabled):hover{background:var(--s6);box-shadow:0 8px 36px rgba(255,255,255,.2);transform:translateY(-1px)}
.btn-g{background:transparent;color:var(--s4);border:1px solid var(--b2)}
.btn-g:not(:disabled):hover{border-color:var(--b3);color:#fff;background:var(--b0)}
.btn-sm{padding:8px 20px;font-size:12px}
.btn-back{padding:11px 18px;border-radius:40px;background:transparent;border:1px solid var(--b1);color:var(--s3);font-family:var(--fb);font-size:13px;cursor:pointer;transition:all .2s}
.btn-back:hover{border-color:var(--b2);color:#fff}
.btn-next{flex:1;padding:13px 20px;border-radius:40px;background:#fff;border:none;color:var(--void);font-family:var(--fb);font-size:13px;font-weight:600;cursor:pointer;transition:all .2s;display:flex;align-items:center;justify-content:center;gap:7px}
.btn-next:not(:disabled):hover{background:var(--s6);box-shadow:0 4px 20px rgba(255,255,255,.14)}
.btn-next:disabled{opacity:.35;cursor:not-allowed}
.icon-btn{width:36px;height:36px;border-radius:11px;background:#fff;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s;color:var(--void)}
.icon-btn:not(:disabled):hover{background:var(--s6);box-shadow:0 4px 14px rgba(255,255,255,.18)}
.icon-btn:disabled{opacity:.3;cursor:not-allowed}

/* ── ONBOARDING ── */
.onb-shell{width:100%;max-width:420px;background:var(--surface);border:1px solid var(--b1);border-radius:var(--rxl);overflow:hidden;box-shadow:0 1px 0 rgba(255,255,255,.035) inset,0 60px 120px rgba(0,0,0,.7);position:relative;z-index:5}
.onb-head{padding:30px 30px 0;text-align:center}
.onb-ico{width:54px;height:54px;margin:0 auto 20px;border-radius:18px;background:linear-gradient(135deg,var(--b2),var(--b0));border:1px solid var(--b2);display:flex;align-items:center;justify-content:center;font-family:var(--fd);font-size:22px;color:rgba(255,255,255,.6)}
.onb-title{font-family:var(--fd);font-size:26px;font-weight:400;color:#fff;margin-bottom:7px}
.onb-sub{font-size:13px;color:var(--s2);line-height:1.72;margin-bottom:26px}
.onb-body{padding:0 26px 26px}
.pdots{display:flex;justify-content:center;gap:6px;margin-bottom:22px}
.pd{height:5px;border-radius:3px;background:var(--raised);transition:all .35s}
.pd.on{width:24px;background:#fff}
.pd.done{width:8px;background:var(--s1)}
.pd.off{width:8px}
.mode-row{display:flex;gap:3px;padding:3px;background:var(--raised);border-radius:40px;margin-bottom:20px}
.mtab{flex:1;padding:8px;border-radius:40px;background:none;border:none;color:var(--s2);font-family:var(--fb);font-size:12px;font-weight:500;cursor:pointer;transition:all .2s}
.mtab.on{background:#fff;color:var(--void)}
.fl{margin-bottom:13px}
.fl-lbl{font-family:var(--fm);font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--s1);margin-bottom:7px;display:flex;align-items:center;justify-content:space-between}
.fl-lbl a{color:var(--teal);font-size:10px;text-decoration:none}
.fi{width:100%;padding:12px 14px;background:var(--raised);border:1px solid var(--b1);border-radius:var(--r);color:#fff;font-family:var(--fb);font-size:14px;outline:none;transition:all .2s}
.fi::placeholder{color:var(--s0)}
.fi:focus{border-color:var(--b3);background:rgba(255,255,255,.04);box-shadow:0 0 0 3px rgba(255,255,255,.04)}
.fi.mono{font-family:var(--fm);font-size:12px;letter-spacing:.03em}
.key-box{background:var(--raised);border:1px solid rgba(0,229,200,.2);border-radius:var(--r);padding:14px;margin-bottom:12px}
.key-lbl{font-family:var(--fm);font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--teal);margin-bottom:8px;display:flex;align-items:center;justify-content:space-between}
.key-txt{font-family:var(--fm);font-size:12px;color:var(--s5);word-break:break-all;line-height:1.6}
.copy-btn{background:none;border:1px solid var(--b1);color:var(--s2);font-family:var(--fm);font-size:10px;padding:2px 9px;border-radius:6px;cursor:pointer;transition:all .2s}
.copy-btn:hover{color:#fff;border-color:var(--b2)}
.warn-note{padding:12px 14px;background:rgba(255,200,50,.04);border:1px solid rgba(255,200,50,.1);border-radius:var(--r);font-size:12px;color:rgba(255,200,100,.65);line-height:1.65;margin-bottom:18px}
.info-note{font-size:11px;color:var(--s0);line-height:1.65;margin-bottom:16px}
.onb-row{display:flex;gap:8px}
.ready-list{display:flex;flex-direction:column;gap:7px;margin-bottom:20px}
.ready-item{display:flex;align-items:center;gap:11px;padding:11px 13px;background:var(--raised);border:1px solid var(--b1);border-radius:var(--r);font-size:12px;color:var(--s2)}

/* ── APP ── */
#s-app{background:var(--abyss)}
.tbar{position:absolute;top:0;left:0;right:0;z-index:50;height:58px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;background:rgba(6,6,10,.9);backdrop-filter:blur(24px);border-bottom:1px solid var(--b1)}
.tbl{display:flex;align-items:center;gap:10px}
.tbmark{width:30px;height:30px;border-radius:10px;background:linear-gradient(135deg,var(--b2),var(--b0));border:1px solid var(--b2);display:flex;align-items:center;justify-content:center;font-family:var(--fd);font-size:14px;color:rgba(255,255,255,.65)}
.tbname{font-family:var(--fd);font-size:18px;font-weight:400;color:#fff;letter-spacing:.02em}
.tbr{display:flex;align-items:center;gap:7px}
.net-badge{display:flex;align-items:center;gap:5px;padding:5px 11px;border-radius:20px;background:rgba(0,229,200,.07);border:1px solid rgba(0,229,200,.14);font-family:var(--fm);font-size:10px;color:var(--teal);letter-spacing:.08em}
.net-dot{width:6px;height:6px;border-radius:50%;background:var(--teal);box-shadow:0 0 7px var(--teal);animation:blink 2s infinite}
.noet-chip{display:flex;align-items:center;gap:5px;padding:5px 11px;border-radius:20px;background:var(--b0);border:1px solid var(--b1);font-family:var(--fm);font-size:11px;color:var(--s4)}
.wlt-btn{padding:6px 14px;border-radius:20px;background:transparent;border:1px solid var(--b2);color:var(--s3);font-family:var(--fb);font-size:11px;font-weight:500;cursor:pointer;transition:all .2s}
.wlt-btn:hover{border-color:var(--b3);color:#fff}
.wlt-btn.connected{border-color:rgba(0,229,200,.25);color:var(--teal);background:rgba(0,229,200,.05)}

/* ── WALLET GATE ── */
.wallet-gate{position:absolute;inset:0;z-index:40;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(3,3,5,.92);backdrop-filter:blur(12px)}
.gate-card{width:100%;max-width:380px;background:var(--surface);border:1px solid var(--b2);border-radius:var(--rxl);padding:32px;text-align:center;box-shadow:0 60px 120px rgba(0,0,0,.7)}
.gate-icon{font-size:44px;margin-bottom:20px}
.gate-title{font-family:var(--fd);font-size:26px;font-weight:400;color:#fff;margin-bottom:8px}
.gate-sub{font-size:13px;color:var(--s2);line-height:1.75;margin-bottom:24px}
.gate-steps{display:flex;flex-direction:column;gap:8px;margin-bottom:24px;text-align:left}
.gate-step{display:flex;align-items:flex-start;gap:10px;padding:10px 12px;background:var(--raised);border:1px solid var(--b1);border-radius:var(--r)}
.gs-num{font-family:var(--fm);font-size:11px;color:var(--teal);flex-shrink:0;margin-top:1px}
.gs-text{font-size:12px;color:var(--s2);line-height:1.5}
.gate-enc{display:flex;align-items:center;justify-content:center;gap:6px;font-family:var(--fm);font-size:10px;color:var(--s0);letter-spacing:.08em;margin-top:14px}

/* Bottom nav */
.bbar{position:absolute;bottom:0;left:0;right:0;z-index:50;padding:10px 14px 22px;background:linear-gradient(to top,var(--abyss) 0%,rgba(6,6,10,.95) 55%,transparent 100%)}
.nav-in{max-width:360px;margin:0 auto;display:flex;align-items:center;background:rgba(255,255,255,.028);border:1px solid var(--b1);border-radius:22px;padding:5px;backdrop-filter:blur(20px)}
.nb{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;padding:9px 4px;border-radius:15px;background:none;border:none;cursor:pointer;color:var(--s1);font-family:var(--fb);font-size:10px;font-weight:500;letter-spacing:.02em;transition:all .25s;position:relative}
.nb svg{width:18px;height:18px;transition:all .25s}
.nb.on{color:#fff;background:rgba(255,255,255,.065)}
.nb.on svg{filter:drop-shadow(0 0 5px rgba(255,255,255,.38))}
.nb.on::after{content:'';position:absolute;bottom:4px;left:50%;transform:translateX(-50%);width:4px;height:4px;border-radius:50%;background:#fff;box-shadow:0 0 6px rgba(255,255,255,.6)}

/* Tab panels */
.tab{display:none;position:absolute;inset:0;overflow:hidden}
.tab.on{display:flex;flex-direction:column}

/* ── CHAT ── */
.chat-head{padding:14px 16px;max-width:640px;width:100%;margin:0 auto}
.ai-card{display:flex;align-items:center;justify-content:space-between;padding:12px 14px}
.ai-l{display:flex;align-items:center;gap:12px}
.ai-av{width:40px;height:40px;border-radius:14px;background:linear-gradient(135deg,var(--b2),var(--b0));border:1px solid var(--b2);display:flex;align-items:center;justify-content:center;font-family:var(--fd);font-size:18px;color:rgba(255,255,255,.6);position:relative}
.ai-live-dot{position:absolute;bottom:-2px;right:-2px;width:11px;height:11px;border-radius:50%;background:var(--teal);border:2px solid var(--surface);box-shadow:0 0 7px var(--teal);animation:blink 2s infinite}
.ai-name{font-size:14px;font-weight:500;color:#fff;margin-bottom:2px}
.ai-info{font-size:10px;color:var(--teal);font-family:var(--fm)}
.enc-badge{display:flex;align-items:center;gap:5px;padding:5px 11px;border-radius:20px;background:rgba(0,229,200,.06);border:1px solid rgba(0,229,200,.14);font-family:var(--fm);font-size:10px;color:var(--teal);letter-spacing:.05em}
.msgs{flex:1;overflow-y:auto;padding:4px 16px 10px;display:flex;flex-direction:column;gap:14px;max-width:640px;width:100%;margin:0 auto}
.msgs::-webkit-scrollbar{width:2px}
.mrow{display:flex;gap:10px;align-items:flex-end}
.mrow.u{flex-direction:row-reverse}
.mav{width:28px;height:28px;flex-shrink:0;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:12px}
.mav.ai{background:linear-gradient(135deg,var(--b2),var(--b0));border:1px solid var(--b2);font-family:var(--fd);color:rgba(255,255,255,.55);font-size:14px}
.mav.u{background:#fff;color:var(--void);font-family:var(--fd);font-weight:600}
.mb{max-width:78%;padding:12px 16px;font-size:14px;line-height:1.7;border-radius:18px;white-space:pre-wrap}
.mb.ai{background:var(--raised);border:1px solid var(--b1);color:var(--s4);border-bottom-left-radius:4px}
.mb.u{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.1);color:var(--s5);border-bottom-right-radius:4px}
.mmeta{font-size:10px;color:var(--s0);margin-top:4px;display:flex;align-items:center;gap:5px}
.enc-tag{color:rgba(0,229,200,.4);font-family:var(--fm)}
.typing-row{display:flex;gap:10px;align-items:flex-end}
.typing-bub{padding:14px 18px;background:var(--raised);border:1px solid var(--b1);border-radius:18px;border-bottom-left-radius:4px;display:flex;align-items:center;gap:5px}
.td{width:6px;height:6px;border-radius:50%;background:var(--s1);animation:tdB 1.4s ease-in-out infinite}
.td:nth-child(2){animation-delay:.22s}.td:nth-child(3){animation-delay:.44s}
@keyframes tdB{0%,60%,100%{transform:translateY(0);opacity:.3}30%{transform:translateY(-7px);opacity:1}}
.qps{padding:0 16px 8px;display:flex;gap:6px;overflow-x:auto;max-width:640px;width:100%;margin:0 auto;scrollbar-width:none}
.qps::-webkit-scrollbar{display:none}
.qp{flex-shrink:0;padding:8px 14px;border-radius:20px;background:var(--raised);border:1px solid var(--b1);color:var(--s2);font-size:12px;cursor:pointer;white-space:nowrap;transition:all .2s;font-family:var(--fb)}
.qp:hover{border-color:var(--b2);color:#fff}
.ci-wrap{padding:8px 16px;max-width:640px;width:100%;margin:0 auto}
.ci-box{display:flex;align-items:flex-end;gap:10px;background:var(--surface);border:1px solid var(--b2);border-radius:20px;padding:10px 10px 10px 16px;transition:all .2s}
.ci-box:focus-within{border-color:var(--b3);box-shadow:0 0 0 3px rgba(255,255,255,.04)}
.ci-ta{flex:1;background:none;border:none;outline:none;color:#fff;font-family:var(--fb);font-size:14px;line-height:1.5;resize:none;min-height:24px;max-height:120px}
.ci-ta::placeholder{color:var(--s0)}
.ci-foot{text-align:center;font-family:var(--fm);font-size:9px;color:var(--s0);letter-spacing:.1em;margin-top:6px}

/* Crisis alert */
.crisis-banner{position:absolute;top:66px;left:12px;right:12px;z-index:60;padding:13px 15px;background:rgba(180,40,40,.12);border:1px solid rgba(220,80,80,.25);border-radius:var(--rl)}
.crisis-banner h4{font-size:13px;color:#f87171;margin-bottom:4px}
.crisis-banner p{font-size:12px;color:rgba(255,255,255,.55);line-height:1.6}

/* ── MOOD ── */
.tscroll{flex:1;overflow-y:auto;padding:16px;max-width:640px;width:100%;margin:0 auto}
.tscroll::-webkit-scrollbar{width:2px}
.sh1{font-family:var(--fd);font-size:26px;font-weight:400;color:#fff;margin-bottom:3px}
.sh2{font-size:11px;color:var(--s0);font-family:var(--fm);margin-bottom:20px;display:flex;align-items:center;gap:6px}
.card{background:var(--surface);border:1px solid var(--b1);border-radius:var(--rl);overflow:hidden;transition:border-color .2s;margin-bottom:14px}
.card:hover{border-color:var(--b2)}
.cp{padding:16px}
.slbl{font-family:var(--fm);font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--s0);margin-bottom:10px}
.sg{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:14px}
.sc{padding:14px;background:var(--raised);border:1px solid var(--b1);border-radius:var(--r);text-align:center}
.sv{font-family:var(--fd);font-size:26px;font-weight:400;color:#fff;line-height:1;margin-bottom:4px}
.sl{font-size:10px;color:var(--s0);font-family:var(--fm);letter-spacing:.06em}
.ch{height:84px;display:flex;align-items:flex-end;gap:3px;padding:0 2px}
.cb{flex:1;border-radius:3px 3px 0 0;background:var(--raised);transition:height .5s;cursor:pointer;position:relative;min-height:4px}
.cb.f{background:linear-gradient(to top,rgba(0,229,200,.22),rgba(0,229,200,.05))}
.cb:hover::after{content:attr(data-v);position:absolute;top:-18px;left:50%;transform:translateX(-50%);font-size:9px;color:var(--s4);font-family:var(--fm);white-space:nowrap}
.mg{display:grid;grid-template-columns:repeat(5,1fr);gap:7px;margin-bottom:14px}
.mo{aspect-ratio:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;border-radius:var(--r);background:var(--raised);border:1px solid var(--b1);cursor:pointer;transition:all .2s;font-size:22px}
.mo span{font-size:10px;color:var(--s0);font-family:var(--fb)}
.mo:hover{transform:translateY(-3px);border-color:var(--b2)}
.mo.sel{transform:translateY(-3px);border-color:var(--b3);background:rgba(255,255,255,.055);box-shadow:0 8px 24px rgba(0,0,0,.4)}
.etags{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px}
.et{padding:5px 12px;border-radius:20px;background:var(--raised);border:1px solid var(--b1);color:var(--s2);font-size:11px;cursor:pointer;transition:all .15s;font-family:var(--fb)}
.et:hover{border-color:var(--b2);color:#fff}
.et.on{background:var(--b1);border-color:var(--b2);color:#fff}

/* ── JOURNAL ── */
.sk-row{display:flex;align-items:center;justify-content:space-between;padding:16px 18px;background:linear-gradient(135deg,var(--b0),rgba(0,0,0,.1));border:1px solid var(--b1);border-radius:var(--rl);margin-bottom:14px}
.sk-l{display:flex;align-items:center;gap:12px}
.flame{font-size:30px;animation:flicker .8s ease-in-out infinite alternate}
@keyframes flicker{from{transform:scale(1)rotate(-1deg)}to{transform:scale(1.07)rotate(1deg)}}
.sn{font-family:var(--fd);font-size:30px;font-weight:300;color:#fff;line-height:1}
.slb{font-size:11px;color:var(--s0);margin-top:2px}
.sr-right{text-align:right}
.srw{font-family:var(--fm);font-size:11px;color:var(--gold);padding:4px 10px;border-radius:12px;background:rgba(255,210,50,.05);border:1px solid rgba(255,210,50,.1)}
.prom-card{padding:14px 16px;margin-bottom:14px;background:rgba(255,255,255,.018);border:1px solid var(--b1);border-left:2px solid var(--s1);border-radius:0 var(--r) var(--r) 0;cursor:pointer;transition:border-left-color .2s}
.prom-card:hover{border-left-color:#fff}
.prom-lbl{font-family:var(--fm);font-size:9px;letter-spacing:.14em;text-transform:uppercase;color:var(--s0);margin-bottom:7px}
.prom-txt{font-family:var(--fd);font-size:15px;font-style:italic;color:var(--s3);line-height:1.5}
.jta{width:100%;min-height:170px;background:var(--raised);border:1px solid var(--b1);border-radius:var(--r);padding:15px;color:#fff;font-family:var(--fb);font-size:14px;line-height:1.8;outline:none;resize:none;transition:all .2s;margin-bottom:8px}
.jta::placeholder{color:var(--s0)}
.jta:focus{border-color:var(--b2);box-shadow:0 0 0 3px var(--b0)}
.wc-row{display:flex;align-items:center;justify-content:space-between;font-family:var(--fm);font-size:10px;color:var(--s0);margin-bottom:12px}
.enc-live{display:flex;align-items:center;gap:5px;color:rgba(0,229,200,.4)}
.enc-d{width:5px;height:5px;border-radius:50%;background:var(--teal);opacity:.4;animation:blink 1.5s infinite}
.ei{padding:15px 16px;cursor:pointer;transition:background .2s}
.ei:hover{background:rgba(255,255,255,.018)}
.ei+.ei{border-top:1px solid var(--b1)}
.edate{font-family:var(--fm);font-size:10px;color:var(--s0);letter-spacing:.06em;margin-bottom:5px}
.eprev{font-size:13px;color:var(--s3);line-height:1.55;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.echips{display:flex;gap:6px;margin-top:6px}
.chip{font-size:10px;padding:2px 8px;border-radius:10px;background:var(--b0);border:1px solid var(--b1);color:var(--s0)}
.chip.t{color:rgba(0,229,200,.5);border-color:rgba(0,229,200,.12)}

/* ── REWARDS ── */
.bal-hero{padding:28px 22px;text-align:center;background:var(--raised);border:1px solid var(--b1);border-radius:var(--rxl);margin-bottom:14px;position:relative;overflow:hidden}
.bal-hero::before{content:'';position:absolute;top:-80px;left:50%;transform:translateX(-50%);width:280px;height:280px;border-radius:50%;background:radial-gradient(circle,rgba(255,255,255,.025),transparent 70%);pointer-events:none}
.bal-lbl{font-family:var(--fm);font-size:10px;letter-spacing:.14em;text-transform:uppercase;color:var(--s0);margin-bottom:10px}
.bal-num{font-family:var(--fd);font-size:52px;font-weight:300;color:#fff;line-height:1;margin-bottom:5px}
.bal-sym{font-family:var(--fm);font-size:12px;color:var(--s1);letter-spacing:.1em;margin-bottom:20px}
.bal-btns{display:flex;gap:8px;justify-content:center;flex-wrap:wrap}
.er{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-bottom:1px solid var(--b1)}
.er:last-child{border-bottom:none}
.erl{display:flex;align-items:center;gap:10px}
.eico{width:33px;height:33px;border-radius:10px;background:var(--raised);border:1px solid var(--b1);display:flex;align-items:center;justify-content:center;font-size:14px}
.en{font-size:13px;color:var(--s4)}
.ed{font-size:11px;color:var(--s0);margin-top:1px}
.ea{font-family:var(--fm);font-size:12px;color:rgba(180,220,150,.8);padding:4px 10px;border-radius:12px;background:rgba(180,220,150,.05);border:1px solid rgba(180,220,150,.1)}
.mg2{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px}
.mc{padding:13px;border-radius:var(--r);background:var(--raised);border:1px solid var(--b1);transition:all .2s}
.mc.done{border-color:rgba(0,229,200,.18);background:rgba(0,229,200,.03)}
.mc:hover{border-color:var(--b2)}
.mci{font-size:20px;margin-bottom:5px}
.mcn{font-size:12px;color:var(--s4);font-weight:500;margin-bottom:2px}
.mcd{font-size:10px;color:var(--s0)}
.mct{font-family:var(--fm);font-size:11px;color:rgba(180,220,150,.6);margin-top:5px}
.mck2{font-size:10px;color:var(--teal);font-family:var(--fm);margin-top:3px}
.tx{display:flex;align-items:center;justify-content:space-between;padding:11px 16px;border-bottom:1px solid var(--b1)}
.tx:last-child{border-bottom:none}
.txl{display:flex;align-items:center;gap:10px}
.txd{width:7px;height:7px;border-radius:50%;background:rgba(0,229,200,.5);box-shadow:0 0 5px rgba(0,229,200,.3)}
.txn{font-size:12px;color:var(--s3)}
.txh{font-size:10px;color:var(--s0);font-family:var(--fm)}
.txa{font-family:var(--fm);font-size:12px;color:rgba(180,220,150,.8)}
.txa.chain{color:var(--teal)}

/* ── ENC FLASH ── */
#enc-flash{position:fixed;inset:0;z-index:500;display:flex;align-items:center;justify-content:center;pointer-events:none;opacity:0;transition:opacity .3s}
#enc-flash.on{opacity:1}
.ef{padding:18px 26px;text-align:center;background:rgba(6,6,10,.97);border:1px solid rgba(0,229,200,.22);border-radius:var(--rl);backdrop-filter:blur(28px);box-shadow:0 0 60px rgba(0,229,200,.07)}
.efl{font-family:var(--fm);font-size:10px;letter-spacing:.15em;text-transform:uppercase;color:var(--teal);margin-bottom:9px;display:flex;align-items:center;gap:7px;justify-content:center}
.efc{font-family:var(--fm);font-size:11px;color:rgba(0,229,200,.38)}
.efb{height:1px;background:rgba(255,255,255,.04);margin-top:11px;overflow:hidden;border-radius:1px}
.efbf{height:100%;background:linear-gradient(90deg,var(--teal),rgba(0,229,200,.3));width:0;transition:width .75s}

/* ── TOAST ── */
#toasts{position:fixed;top:68px;left:50%;transform:translateX(-50%);z-index:9999;width:calc(100% - 28px);max-width:380px;display:flex;flex-direction:column;gap:6px;pointer-events:none}
.tst{padding:11px 15px;border-radius:var(--r);background:rgba(9,9,15,.98);border:1px solid var(--b2);font-size:13px;color:var(--s4);display:flex;align-items:center;gap:9px;backdrop-filter:blur(24px);box-shadow:0 8px 30px rgba(0,0,0,.5);animation:tIn .3s ease,tOut .3s ease 2.7s forwards}
.tst.ok{border-color:rgba(0,229,200,.2)}
.tst.err{border-color:rgba(200,60,60,.2)}
.tst.warn{border-color:rgba(255,180,50,.2)}
@keyframes tIn{from{opacity:0;transform:translateY(-10px)}to{opacity:1;transform:none}}
@keyframes tOut{to{opacity:0;transform:translateY(-10px)}}

/* ── OVERLAY ── */
.ov{display:none;position:fixed;inset:0;z-index:200;background:rgba(2,2,4,.93);backdrop-filter:blur(12px);align-items:center;justify-content:center;padding:20px}
.ov.open{display:flex}
.ovc{width:100%;max-width:420px;background:var(--surface);border:1px solid var(--b2);border-radius:var(--rxl);padding:26px;box-shadow:0 60px 120px rgba(0,0,0,.7);position:relative;max-height:85vh;overflow-y:auto}
.ovc::-webkit-scrollbar{width:2px}
.ov-title{font-family:var(--fd);font-size:22px;font-weight:400;color:#fff;margin-bottom:8px}
.ov-sub{font-size:13px;color:var(--s2);line-height:1.65;margin-bottom:20px}
.ov-close{position:absolute;top:18px;right:18px;background:none;border:none;color:var(--s1);font-size:20px;cursor:pointer;line-height:1}

/* ── ANIMS ── */
@keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
.fu{opacity:0;animation:fadeUp .45s ease forwards}
.d1{animation-delay:.05s}.d2{animation-delay:.1s}.d3{animation-delay:.15s}.d4{animation-delay:.2s}.d5{animation-delay:.25s}
.divider{height:1px;background:var(--b1);margin:14px 0}
</style>

<!-- Background -->
<div id="bg">
  <div class="orb orb1"></div>
  <div class="orb orb2"></div>
  <div class="orb orb3"></div>
  <canvas id="nc"></canvas>
  <div class="scan"></div>
  <div class="grain"></div>
</div>

<!-- Encrypt flash -->
<div id="enc-flash">
  <div class="ef">
    <div class="efl">⬡ Encrypting</div>
    <div class="efc" id="ef-c">██████████████</div>
    <div class="efb"><div class="efbf" id="ef-f"></div></div>
  </div>
</div>

<!-- Toasts -->
<div id="toasts"></div>

<!-- ══ LANDING ══ -->
<div class="screen" id="s-land">
  <div class="scenter">
    <div class="logo-wrap fu d1">
      <div class="lring"></div><div class="lring"></div><div class="lring"></div>
      <div class="lcore">𝜓</div>
    </div>
    <div class="eyebrow fu d2"><span class="pdot"></span>COTI Network · Privacy-First AI</div>
    <h1 class="land-h1 fu d2"><em>NOETICA</em></h1>
    <p class="land-tag fu d3">The Private Science of Your Mind</p>
    <p class="land-desc fu d4">The first AI mental companion that remembers everything — without ever exposing your data. Encrypted with AES-256-GCM. Rewarded on COTI Network.</p>
    <div class="land-btns fu d5">
      <button class="btn btn-w" onclick="UI.goto('s-onb')">Open My Sanctuary <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></button>
      <button class="btn btn-g" onclick="UI.showOv('ov-return')">Return to Vault</button>
    </div>
    <div class="trust-row fu d5">
      <span class="tpill">AES-256-GCM</span>
      <span class="tpill">COTI Testnet</span>
      <span class="tpill">Zero-Knowledge</span>
      <span class="tpill">On-chain Rewards</span>
    </div>
  </div>
  <div class="enter-hint" onclick="UI.goto('s-onb')">
    <div class="enter-line"></div>Enter
  </div>
</div>

<!-- ══ ONBOARDING ══ -->
<div class="screen out" id="s-onb">
  <button onclick="UI.goto('s-land')" style="position:absolute;top:18px;left:18px;z-index:10;background:none;border:1px solid var(--b1);border-radius:20px;color:var(--s2);font-family:var(--fb);font-size:12px;padding:7px 16px;cursor:pointer">← Back</button>
  <div class="scenter">
  <div class="onb-shell">
    <!-- Step 1 -->
    <div id="st1">
      <div class="onb-head">
        <div class="onb-ico">𝜓</div>
        <div class="onb-title">Create Your Vault</div>
        <div class="onb-sub">Your private sanctuary. No email. No account. Complete privacy — guaranteed by AES-256-GCM encryption.</div>
      </div>
      <div class="onb-body">
        <div class="pdots"><div class="pd on"></div><div class="pd off"></div><div class="pd off"></div></div>
        <div class="mode-row">
          <button class="mtab on" id="mt-new" onclick="ONB.setMode('new')">New Vault</button>
          <button class="mtab" id="mt-ret" onclick="ONB.setMode('ret')">Return</button>
        </div>
        <div id="form-new">
          <div class="fl">
            <div class="fl-lbl">Your name</div>
            <input class="fi" id="inp-name" type="text" placeholder="What should I call you?" autocomplete="off" oninput="ONB.check()"/>
          </div>
        </div>
        <div id="form-ret" style="display:none">
          <div class="fl">
            <div class="fl-lbl">Vault Key</div>
            <input class="fi mono" id="inp-rk" type="password" placeholder="Your 32-char vault key..." oninput="ONB.check()"/>
          </div>
        </div>
        <div class="info-note">API key is loaded from your <code>.env</code> file — never entered in this interface.</div>
        <div class="onb-row">
          <button class="btn-next" id="st1-btn" onclick="ONB.next1()" disabled>Continue <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></button>
        </div>
      </div>
    </div>
    <!-- Step 2 -->
    <div id="st2" style="display:none">
      <div class="onb-head">
        <div class="onb-ico">🗝</div>
        <div class="onb-title">Your Vault Key</div>
        <div class="onb-sub">This encrypts everything. Only you hold this — we can never recover it.</div>
      </div>
      <div class="onb-body">
        <div class="pdots"><div class="pd done"></div><div class="pd on"></div><div class="pd off"></div></div>
        <div class="key-box">
          <div class="key-lbl"><span>⬡ Encryption Key</span><button class="copy-btn" onclick="ONB.copyKey()">Copy</button></div>
          <div class="key-txt" id="key-disp">—</div>
        </div>
        <div class="warn-note">⚠ Save this key safely. Losing it means losing all your data — permanently.</div>
        <div class="onb-row">
          <button class="btn-back" onclick="ONB.back1()">← Back</button>
          <button class="btn-next" onclick="ONB.next2()">I've saved it ✓</button>
        </div>
      </div>
    </div>
    <!-- Step 3 -->
    <div id="st3" style="display:none">
      <div class="onb-head">
        <div class="onb-ico">💜</div>
        <div class="onb-title" id="st3-name">Welcome</div>
        <div class="onb-sub">Your sanctuary is ready. Connect your COTI wallet to begin.</div>
      </div>
      <div class="onb-body">
        <div class="pdots"><div class="pd done"></div><div class="pd done"></div><div class="pd on"></div></div>
        <div class="ready-list">
          <div class="ready-item"><span>🔐</span><span>AES-256-GCM encryption active</span></div>
          <div class="ready-item"><span>🤖</span><span id="ai-stat">Neural intelligence ready</span></div>
          <div class="ready-item"><span>⛓</span><span>COTI Testnet · Chain ID 7082400</span></div>
          <div class="ready-item"><span>🔑</span><span>API key loaded from <code>.env</code></span></div>
        </div>
        <button class="btn-next" onclick="ONB.enter()">Enter NOETICA <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></button>
      </div>
    </div>
  </div>
  </div>
</div>

<!-- ══ APP ══ -->
<div class="screen out" id="s-app">
  <!-- Topbar -->
  <div class="tbar">
    <div class="tbl">
      <div class="tbmark">𝜓</div>
      <span class="tbname">NOETICA</span>
    </div>
    <div class="tbr">
      <div class="net-badge"><div class="net-dot"></div>COTI</div>
      <div class="noet-chip">◈ <span id="top-bal">0</span> <span style="color:var(--s0)">NOET</span></div>
      <button class="wlt-btn" id="wlt-btn" onclick="APP.connectWallet()">Connect Wallet</button>
    </div>
  </div>

  <!-- ─ CHAT ─ -->
  <div class="tab on" id="t-chat">
    <!-- Wallet gate overlay for chat -->
    <div class="wallet-gate" id="chat-gate" style="display:none">
      <div class="gate-card">
        <div class="gate-icon">🔐</div>
        <div class="gate-title">Connect to Continue</div>
        <div class="gate-sub">NOETICA requires a COTI wallet connection to interact with the neural intelligence. This ensures your rewards are recorded on-chain.</div>
        <div class="gate-steps">
          <div class="gate-step"><span class="gs-num">01</span><span class="gs-text">Connect MetaMask — COTI Testnet will be added automatically</span></div>
          <div class="gate-step"><span class="gs-num">02</span><span class="gs-text">Get free testnet COTI from the faucet if needed</span></div>
          <div class="gate-step"><span class="gs-num">03</span><span class="gs-text">Your conversations remain encrypted — wallet only used for rewards</span></div>
        </div>
        <button class="btn btn-w" style="width:100%;justify-content:center" onclick="APP.connectWallet()">
          Connect COTI Wallet
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        </button>
        <div class="gate-enc">
          <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
          AES-256-GCM · Conversations encrypted client-side
        </div>
      </div>
    </div>

    <div class="chat-head">
      <div class="card ai-card">
        <div class="ai-l">
          <div class="ai-av">𝜓<div class="ai-live-dot"></div></div>
          <div>
            <div class="ai-name">NOETICA Intelligence</div>
            <div class="ai-info">Neural Core · Privacy Encrypted · COTI Network</div>
          </div>
        </div>
        <div class="enc-badge"><svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>E2E ENCRYPTED</div>
      </div>
    </div>
    <div class="msgs" id="msgs"></div>
    <div class="qps" id="qps">
      <button class="qp" onclick="CHAT.quick(this)">I feel anxious today</button>
      <button class="qp" onclick="CHAT.quick(this)">Help me process my thoughts</button>
      <button class="qp" onclick="CHAT.quick(this)">I need to vent</button>
      <button class="qp" onclick="CHAT.quick(this)">I feel overwhelmed</button>
      <button class="qp" onclick="CHAT.quick(this)">I had a hard day</button>
    </div>
    <div class="ci-wrap">
      <div class="ci-box">
        <textarea class="ci-ta" id="ci" placeholder="Share what's on your mind..." rows="1"
          onkeydown="CHAT.kd(event)" oninput="CHAT.resize(this)"></textarea>
        <button class="icon-btn" id="sbtn" onclick="CHAT.send()" disabled>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M22 2L11 13"/><path d="M22 2L15 22 11 13 2 9l20-7z"/></svg>
        </button>
      </div>
      <div class="ci-foot">AES-256-GCM · NOETICA does not store raw data · COTI Network</div>
    </div>
  </div>

  <!-- ─ MOOD ─ -->
  <div class="tab" id="t-mood">
    <div class="tscroll">
      <div class="sh1 fu">Mood</div>
      <div class="sh2 fu d1"><span style="color:var(--teal)">⬡</span> Encrypted · Private analytics</div>
      <div class="sg fu d1">
        <div class="sc"><div class="sv" id="m-avg">—</div><div class="sl">avg score</div></div>
        <div class="sc"><div class="sv" id="m-cnt">0</div><div class="sl">total logs</div></div>
        <div class="sc"><div class="sv" id="m-trend">—</div><div class="sl">trend</div></div>
      </div>
      <div class="card fu d2"><div class="cp">
        <div class="slbl">14-day journey</div>
        <div class="ch" id="mood-ch"></div>
        <div style="display:flex;justify-content:space-between;margin-top:4px;font-size:10px;color:var(--s0);font-family:var(--fm)"><span id="ch-s">—</span><span>Today</span></div>
      </div></div>
      <div class="card fu d3" style="padding:16px" id="checkin-card">
        <div class="slbl">How are you right now?</div>
        <div class="mg">
          <div class="mo" data-score="10" data-label="Radiant" onclick="MOOD.sel(this)">😄<span>Radiant</span></div>
          <div class="mo" data-score="7.5" data-label="Good" onclick="MOOD.sel(this)">🙂<span>Good</span></div>
          <div class="mo" data-score="5" data-label="Neutral" onclick="MOOD.sel(this)">😐<span>Neutral</span></div>
          <div class="mo" data-score="2.5" data-label="Low" onclick="MOOD.sel(this)">😔<span>Low</span></div>
          <div class="mo" data-score="1" data-label="Rough" onclick="MOOD.sel(this)">😩<span>Rough</span></div>
        </div>
        <div class="slbl">Emotions present</div>
        <div class="etags">
          <div class="et" onclick="MOOD.tag(this)">Calm</div><div class="et" onclick="MOOD.tag(this)">Anxious</div>
          <div class="et" onclick="MOOD.tag(this)">Grateful</div><div class="et" onclick="MOOD.tag(this)">Tired</div>
          <div class="et" onclick="MOOD.tag(this)">Hopeful</div><div class="et" onclick="MOOD.tag(this)">Frustrated</div>
          <div class="et" onclick="MOOD.tag(this)">Lonely</div><div class="et" onclick="MOOD.tag(this)">Content</div>
          <div class="et" onclick="MOOD.tag(this)">Energized</div><div class="et" onclick="MOOD.tag(this)">Overwhelmed</div>
        </div>
        <button class="btn-next" id="log-mood-btn" onclick="MOOD.log()" disabled style="font-size:13px;padding:12px">
          Log Mood · Earn 5 NOET ◈
        </button>
      </div>
      <div class="card fu d4" id="mood-hist" style="display:none">
        <div class="slbl" style="padding:14px 16px 0">Recent logs</div>
        <div id="mood-hist-list"></div>
      </div>
    </div>
  </div>

  <!-- ─ JOURNAL ─ -->
  <div class="tab" id="t-journal">
    <div class="tscroll">
      <div class="sh1 fu">Journal</div>
      <div class="sh2 fu d1"><span style="color:var(--teal)">⬡</span> Zero-knowledge · Your words only</div>
      <div class="sk-row fu d1">
        <div class="sk-l"><div class="flame">🔥</div><div><div class="sn" id="sk-n">0</div><div class="slb">day streak</div></div></div>
        <div class="sr-right">
          <div class="srw" id="sk-rw">+10 NOET/entry</div>
          <div style="font-size:10px;color:var(--s0);margin-top:4px;font-family:var(--fm)" id="sk-best">best: 0 days</div>
        </div>
      </div>
      <div class="prom-card fu d2" onclick="JOURNAL.newPrompt()">
        <div class="prom-lbl">✦ Reflection prompt · tap to refresh</div>
        <div class="prom-txt" id="prom-txt">Loading...</div>
      </div>
      <div class="card fu d3" style="padding:16px;margin-bottom:14px" id="write-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
          <div class="slbl" style="margin:0">Today's entry</div>
          <div class="enc-live" id="enc-live" style="display:none"><div class="enc-d"></div><span style="font-family:var(--fm);font-size:10px">encrypting</span></div>
        </div>
        <textarea class="jta" id="jta" placeholder="Write freely. This space is truly yours. Everything is encrypted as you type." oninput="JOURNAL.type(this)"></textarea>
        <div class="wc-row">
          <span id="wc">0 words</span>
          <div id="enc-inline" style="display:none" class="enc-live"><div class="enc-d"></div><span style="font-family:var(--fm);font-size:10px">⬡ live encryption</span></div>
        </div>
        <button class="btn-next" id="save-btn" onclick="JOURNAL.save()" style="font-size:13px;padding:12px" disabled>
          Save & Encrypt · Earn NOET ◈
        </button>
      </div>
      <div class="card fu d4" id="past-wrap" style="display:none">
        <div class="slbl" style="padding:14px 16px 6px">Past entries</div>
        <div id="past-list"></div>
      </div>
    </div>
  </div>

  <!-- ─ REWARDS ─ -->
  <div class="tab" id="t-rewards">
    <div class="tscroll">
      <div class="sh1 fu">Rewards</div>
      <div class="sh2 fu d1">Earn NOET tokens for taking care of your mind</div>
      <div class="bal-hero fu d1">
        <div class="bal-lbl">NOET Balance · COTI Testnet</div>
        <div class="bal-num" id="big-bal">0</div>
        <div class="bal-sym">NOETICA TOKEN</div>
        <div class="bal-btns">
          <button class="btn btn-w btn-sm" onclick="APP.connectWallet()">Connect Wallet</button>
          <a href="https://faucet.coti.io" target="_blank" class="btn btn-g btn-sm" style="text-decoration:none">Faucet 🚰</a>
          <a href="https://testnet.cotiscan.io" target="_blank" class="btn btn-g btn-sm" style="text-decoration:none">Explorer ↗</a>
        </div>
      </div>
      <div class="card fu d2" style="margin-bottom:14px">
        <div class="slbl" style="padding:14px 16px 6px">How to earn NOET</div>
        <div class="er"><div class="erl"><div class="eico">✍</div><div><div class="en">Journal Entry</div><div class="ed">Write ≥10 words daily</div></div></div><div class="ea">+10 NOET</div></div>
        <div class="er"><div class="erl"><div class="eico">📊</div><div><div class="en">Mood Check-in</div><div class="ed">Log your daily mood</div></div></div><div class="ea">+5 NOET</div></div>
        <div class="er"><div class="erl"><div class="eico">🔥</div><div><div class="en">3-Day Streak</div><div class="ed">Journal 3 days in a row</div></div></div><div class="ea">+25 NOET</div></div>
        <div class="er"><div class="erl"><div class="eico">⚡</div><div><div class="en">7-Day Streak</div><div class="ed">One week of consistency</div></div></div><div class="ea">+75 NOET</div></div>
        <div class="er"><div class="erl"><div class="eico">👑</div><div><div class="en">30-Day Legend</div><div class="ed">Ultimate commitment</div></div></div><div class="ea">+300 NOET</div></div>
        <div class="er"><div class="erl"><div class="eico">🎯</div><div><div class="en">First Session</div><div class="ed">One-time welcome reward</div></div></div><div class="ea">+20 NOET</div></div>
      </div>
      <div class="slbl fu d3">Milestones</div>
      <div class="mg2 fu d3" id="mile-grid"></div>
      <div class="card fu d4" style="margin-top:0">
        <div class="slbl" style="padding:14px 16px 6px">Reward history</div>
        <div id="tx-list"><div style="padding:16px;text-align:center;font-size:12px;color:var(--s0)">No rewards yet — start journaling 💜</div></div>
      </div>
    </div>
  </div>

  <!-- Bottom nav -->
  <div class="bbar">
    <div class="nav-in">
      <button class="nb on" id="nb-chat" onclick="APP.tab('chat')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>Mind
      </button>
      <button class="nb" id="nb-mood" onclick="APP.tab('mood')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>Mood
      </button>
      <button class="nb" id="nb-journal" onclick="APP.tab('journal')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>Journal
      </button>
      <button class="nb" id="nb-rewards" onclick="APP.tab('rewards')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>Rewards
      </button>
    </div>
  </div>
</div>

<!-- ── Return Overlay ── -->
<div class="ov" id="ov-return">
  <div class="ovc">
    <button class="ov-close" onclick="UI.closeOv('ov-return')">×</button>
    <div class="ov-title">Return to Vault</div>
    <div class="ov-sub">Enter your vault key to unlock your encrypted memories.</div>
    <div class="fl-lbl">Vault Key</div>
    <input class="fi mono" id="ret-key" type="password" placeholder="Your 32-char vault key..." style="margin-bottom:14px"/>
    <button class="btn-next" onclick="ONB.returnVault()">Unlock Vault</button>
  </div>
</div>

<!-- ── Entry Overlay ── -->
<div class="ov" id="ov-entry">
  <div class="ovc">
    <button class="ov-close" onclick="UI.closeOv('ov-entry')">×</button>
    <div class="ov-title" id="ov-e-d"></div>
    <div style="font-size:13px;color:var(--s2);line-height:1.8;margin-top:12px;white-space:pre-wrap" id="ov-e-b"></div>
    <div id="ov-e-i" style="display:none;margin-top:14px;padding:12px 14px;background:var(--b0);border:1px solid var(--b1);border-radius:var(--r);font-size:12px;color:var(--s1);line-height:1.65"></div>
  </div>
</div>
`
}

// ═══════════════════════════════════════════
// NEURAL CANVAS
// ═══════════════════════════════════════════
function initCanvas() {
  const c = document.getElementById('nc')
  if (!c) return
  const ctx = c.getContext('2d')
  let W, H
  const resize = () => { W = c.width = innerWidth; H = c.height = innerHeight }
  resize(); window.addEventListener('resize', resize)
  const pts = Array.from({length:55}, () => ({
    x:Math.random()*innerWidth, y:Math.random()*innerHeight,
    vx:(Math.random()-.5)*.22, vy:(Math.random()-.5)*.22,
    r:Math.random()*1.2+.3, op:Math.random()*.28+.05,
    col:Math.random()>.4?'255,255,255':'0,229,200'
  }))
  ;(function draw() {
    ctx.clearRect(0,0,W,H)
    for (let i=0;i<pts.length;i++) {
      for (let j=i+1;j<pts.length;j++) {
        const dx=pts[i].x-pts[j].x, dy=pts[i].y-pts[j].y
        const d=Math.sqrt(dx*dx+dy*dy)
        if (d<110) {
          ctx.beginPath()
          ctx.strokeStyle=`rgba(255,255,255,${.05*(1-d/110)})`
          ctx.lineWidth=.4
          ctx.moveTo(pts[i].x,pts[i].y); ctx.lineTo(pts[j].x,pts[j].y); ctx.stroke()
        }
      }
      ctx.beginPath(); ctx.arc(pts[i].x,pts[i].y,pts[i].r,0,Math.PI*2)
      ctx.fillStyle=`rgba(${pts[i].col},${pts[i].op})`; ctx.fill()
      pts[i].x+=pts[i].vx; pts[i].y+=pts[i].vy
      if(pts[i].x<0||pts[i].x>W) pts[i].vx*=-1
      if(pts[i].y<0||pts[i].y>H) pts[i].vy*=-1
    }
    requestAnimationFrame(draw)
  })()
}

// ═══════════════════════════════════════════
// UI HELPERS
// ═══════════════════════════════════════════
const UI = {
  goto(id) {
    document.querySelectorAll('.screen').forEach(s=>s.classList.add('out'))
    document.getElementById(id).classList.remove('out')
  },
  showOv(id)  { document.getElementById(id).classList.add('open') },
  closeOv(id) { document.getElementById(id).classList.remove('open') },
}

function toast(msg, type='ok') {
  const el = document.getElementById('toasts')
  const icons = {ok:'◈', err:'✕', warn:'⚠'}
  const c = document.createElement('div')
  c.className = `tst ${type}`
  c.innerHTML = `<span style="color:${type==='ok'?'var(--teal)':type==='warn'?'rgba(255,180,50,.8)':'#f87171'}">${icons[type]}</span>${msg}`
  el.appendChild(c)
  setTimeout(() => c.remove(), 3000)
}

async function encFlash(text) {
  const el = document.getElementById('enc-flash')
  const ct = document.getElementById('ef-c')
  const ff = document.getElementById('ef-f')
  ct.textContent = obfuscate(text.slice(0,40), .82)
  el.classList.add('on'); ff.style.width='100%'
  await new Promise(r=>setTimeout(r,820))
  el.classList.remove('on'); ff.style.width='0'
}

// ═══════════════════════════════════════════
// ONBOARDING
// ═══════════════════════════════════════════
let _genKey = ''
const ONB = {
  mode: 'new',
  setMode(m) {
    this.mode = m
    ;['new','ret'].forEach(x => {
      document.getElementById(`mt-${x}`).classList.toggle('on', x===m)
      document.getElementById(`form-${x}`).style.display = x===m?'':'none'
    })
    this.check()
  },
  check() {
    const n  = document.getElementById('inp-name')?.value.trim()
    const rk = document.getElementById('inp-rk')?.value.trim()
    document.getElementById('st1-btn').disabled = this.mode==='new' ? n.length<2 : rk.length<10
  },
  async next1() {
    if (this.mode === 'ret') { await this.returnVault(); return }
    S.name = document.getElementById('inp-name').value.trim()
    _genKey = genVaultKey()
    document.getElementById('key-disp').textContent = _genKey
    document.getElementById('st1').style.display = 'none'
    document.getElementById('st2').style.display = 'block'
  },
  back1() {
    document.getElementById('st2').style.display = 'none'
    document.getElementById('st1').style.display = 'block'
  },
  next2() {
    S.vaultKey = _genKey
    document.getElementById('st3-name').textContent = `Welcome, ${S.name}`
    document.getElementById('ai-stat').textContent = Cfg.hasApiKey()
      ? 'Neural intelligence connected'
      : '⚠ No API key — add VITE_AI_API_KEY to .env'
    document.getElementById('st2').style.display = 'none'
    document.getElementById('st3').style.display = 'block'
  },
  copyKey() { navigator.clipboard.writeText(_genKey); toast('Vault key copied') },
  async enter() {
    await saveVault()
    APP.init()
    UI.goto('s-app')
    // Show wallet gate if not connected
    if (!isConnected()) {
      document.getElementById('chat-gate').style.display = 'flex'
    }
  },
  async returnVault() {
    const key = (document.getElementById('ret-key') || document.getElementById('inp-rk'))?.value.trim()
    if (!key) { toast('Enter your vault key', 'err'); return }
    try {
      await loadVault(key)
      UI.closeOv('ov-return')
      APP.init()
      UI.goto('s-app')
      toast(`Welcome back, ${S.name} 💜`)
      if (!isConnected()) document.getElementById('chat-gate').style.display = 'flex'
    } catch {
      toast('Invalid vault key', 'err')
    }
  },
}

// ═══════════════════════════════════════════
// APP
// ═══════════════════════════════════════════
const APP = {
  init() {
    if (!S.messages.length) {
      S.messages = [{
        role:'assistant',
        content:`Hello, ${S.name} 💜\n\nI'm NOETICA — your private neural companion. Everything you share is encrypted with AES-256-GCM before it leaves your device.\n\nTo begin our conversation and receive NOET rewards, please connect your COTI wallet using the button above.\n\nThis is your sanctuary. I'm here whenever you're ready.`,
        ts: Date.now()
      }]
    }
    CHAT.render()
    MOOD.renderChart()
    JOURNAL.renderHistory()
    JOURNAL.newPrompt()
    this.updateBal()
    document.getElementById('sk-n').textContent = S.streak
    document.getElementById('sk-best').textContent = `best: ${S.bestStreak} days`
    this.updReward()
    const today = new Date().toDateString()
    S.journaledToday = S.entries.some(e=>new Date(e.ts).toDateString()===today)
    if (S.journaledToday) {
      document.getElementById('write-card').innerHTML = `<div style="padding:22px;text-align:center"><div style="font-size:34px;margin-bottom:10px">✅</div><div style="font-size:14px;color:var(--s2)">Journaled today — come back tomorrow 🔥</div></div>`
    }
  },

  tab(t) {
    S.tab = t
    document.querySelectorAll('.tab').forEach(x=>x.classList.remove('on'))
    document.querySelectorAll('.nb').forEach(x=>x.classList.remove('on'))
    document.getElementById('t-'+t).classList.add('on')
    document.getElementById('nb-'+t).classList.add('on')
    if (t==='rewards') REWARDS.renderMilestones()
    if (t==='mood') MOOD.renderChart()
  },

  async connectWallet() {
    try {
      const addr = await connectWallet()
      S.walletAddr = addr
      const btn = document.getElementById('wlt-btn')
      btn.textContent = shortAddr(addr)
      btn.classList.add('connected')
      // Hide chat gate
      document.getElementById('chat-gate').style.display = 'none'
      toast(`Connected: ${shortAddr(addr)} · COTI Testnet`)
      // First session reward
      await REWARDS.earn('first', 20)
      // Refresh on-chain balance
      const bal = await getNOETBalance(addr)
      if (parseFloat(bal) > 0) {
        S.noet = Math.max(S.noet, Math.floor(parseFloat(bal)))
        this.updateBal()
      }
    } catch (e) {
      if (e.code === 4001) toast('Connection rejected', 'warn')
      else toast(e.message || 'Could not connect wallet', 'err')
    }
  },

  updateBal() {
    document.getElementById('top-bal').textContent = S.noet.toLocaleString()
    document.getElementById('big-bal').textContent = S.noet.toLocaleString()
    REWARDS.renderTx()
  },

  updReward() {
    const s = S.streak
    let r = '+10 NOET/entry'
    if (s >= 30) r = '+300 NOET streak!'
    else if (s >= 7) r = '+75 NOET streak!'
    else if (s >= 3) r = '+25 NOET streak!'
    document.getElementById('sk-rw').textContent = r
  },
}

// ═══════════════════════════════════════════
// CHAT
// ═══════════════════════════════════════════
const CHAT = {
  render() {
    const c = document.getElementById('msgs'); c.innerHTML = ''
    S.messages.forEach(m => {
      const row = document.createElement('div')
      row.className = `mrow ${m.role==='user'?'u':''}`
      const av = document.createElement('div')
      av.className = `mav ${m.role==='user'?'u':'ai'}`
      av.textContent = m.role==='user' ? (S.name[0]||'U').toUpperCase() : '𝜓'
      const inn = document.createElement('div')
      const bub = document.createElement('div')
      bub.className = `mb ${m.role==='user'?'u':'ai'}`
      bub.textContent = m.content
      const meta = document.createElement('div')
      meta.className = 'mmeta'
      const t = m.ts ? new Date(m.ts).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}) : ''
      meta.innerHTML = `${m.role==='user'?'<span class="enc-tag">⬡ encrypted</span>':''}<span>${t}</span>`
      inn.appendChild(bub); inn.appendChild(meta)
      row.appendChild(av); row.appendChild(inn)
      c.appendChild(row)
    })
    setTimeout(() => c.scrollTop = c.scrollHeight, 50)
    if (S.uMsgs > 2) document.getElementById('qps').style.display = 'none'
  },

  addTyping() {
    const c = document.getElementById('msgs')
    const r = document.createElement('div'); r.className='typing-row'; r.id='typing'
    r.innerHTML = `<div class="mav ai">𝜓</div><div class="typing-bub"><div class="td"></div><div class="td"></div><div class="td"></div></div>`
    c.appendChild(r); c.scrollTop = c.scrollHeight
  },
  remTyping() { document.getElementById('typing')?.remove() },

  kd(e) { if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();this.send()} },
  resize(el) {
    el.style.height='auto'; el.style.height=Math.min(el.scrollHeight,120)+'px'
    document.getElementById('sbtn').disabled = !el.value.trim()
  },
  quick(btn) { this.send(btn.textContent) },

  async send(txt) {
    // Require wallet connection
    if (!isConnected()) {
      document.getElementById('chat-gate').style.display = 'flex'
      toast('Connect your COTI wallet to chat', 'warn')
      return
    }
    if (!Cfg.hasApiKey()) {
      toast('Add VITE_AI_API_KEY to your .env file', 'err')
      return
    }
    const inp = document.getElementById('ci')
    const msg = (txt || inp.value).trim()
    if (!msg || S.isTyping) return
    inp.value = ''; inp.style.height='auto'
    document.getElementById('sbtn').disabled = true

    // Check crisis
    const crisis = detectCrisis(msg)
    if (crisis === 'high') {
      const b = document.createElement('div')
      b.className = 'crisis-banner'; b.id = 'crisis-b'
      b.innerHTML = `<h4>You're not alone 💜</h4><p>📞 988 Suicide &amp; Crisis Lifeline &nbsp;|&nbsp; 💬 Text HOME to 741741</p>`
      document.getElementById('t-chat').appendChild(b)
      setTimeout(() => b.remove(), 8000)
    }

    await encFlash(msg)
    S.messages.push({role:'user', content:msg, ts:Date.now()})
    this.render(); S.isTyping=true; this.addTyping()

    try {
      const reply = await sendToAI(S.messages)
      this.remTyping()
      S.messages.push({role:'assistant', content:reply, ts:Date.now()})
      this.render()
    } catch(e) {
      this.remTyping()
      const err = e.message.includes('NO_API_KEY')
        ? '⚠ No API key — add VITE_AI_API_KEY to your .env file and restart.'
        : e.message.includes('401') || e.message.includes('403')
        ? '⚠ API key invalid or expired. Check portal.nousresearch.com'
        : '⚠ Connection issue. Your message is safe — please try again.'
      S.messages.push({role:'assistant', content:err, ts:Date.now()})
      this.render()
    }

    S.isTyping = false
    await saveVault()
  },
}

// ═══════════════════════════════════════════
// MOOD
// ═══════════════════════════════════════════
const MOOD = {
  sel(el) {
    document.querySelectorAll('.mo').forEach(m=>m.classList.remove('sel'))
    el.classList.add('sel')
    S.selMood = {score:+el.dataset.score, label:el.dataset.label, emoji:el.children[0].textContent}
    document.getElementById('log-mood-btn').disabled = false
  },
  tag(el) {
    el.classList.toggle('on')
    const t = el.textContent
    el.classList.contains('on') ? S.selTags.push(t) : (S.selTags = S.selTags.filter(x=>x!==t))
  },
  async log() {
    if (!S.selMood) return
    const entry = {...S.selMood, tags:[...S.selTags], ts:Date.now()}
    S.moods.push(entry); S.todayMood = entry
    S.selMood=null; S.selTags=[]
    document.querySelectorAll('.mo').forEach(m=>m.classList.remove('sel'))
    document.querySelectorAll('.et').forEach(t=>t.classList.remove('on'))
    document.getElementById('log-mood-btn').disabled = true
    await REWARDS.earn('mood', 5)
    await saveVault()
    this.renderChart()
    toast(`Mood logged · +5 NOET ◈`)
    document.getElementById('checkin-card').innerHTML = `<div style="padding:22px;text-align:center"><div style="font-size:34px;margin-bottom:10px">${entry.emoji}</div><div style="font-size:14px;color:var(--s2)">Mood logged for today 💜</div><div style="font-size:11px;color:var(--s0);margin-top:4px;font-family:var(--fm)">+5 NOET · encrypted</div></div>`
  },
  renderChart() {
    const today = new Date(), bars=[], labels=[]
    for(let i=13;i>=0;i--){
      const d=new Date(today); d.setDate(d.getDate()-i)
      const ds=d.toDateString()
      const dm=S.moods.filter(m=>new Date(m.ts).toDateString()===ds)
      const avg=dm.length?dm.reduce((a,m)=>a+m.score,0)/dm.length:null
      bars.push(avg); labels.push(d.toLocaleDateString('en',{month:'short',day:'numeric'}))
    }
    const ch=document.getElementById('mood-ch'); ch.innerHTML=''
    bars.forEach((v) => {
      const b=document.createElement('div'); b.className='cb'+(v?' f':'')
      b.style.height=(v?(v/10)*100:5)+'%'
      if(v){b.dataset.v=v.toFixed(1);const col=v>=7?'0,229,200':v>=5?'180,180,220':'180,80,80';b.style.background=`linear-gradient(to top,rgba(${col},.22),rgba(${col},.05))`}
      ch.appendChild(b)
    })
    if(S.moods.length){
      const avg=(S.moods.reduce((a,m)=>a+m.score,0)/S.moods.length).toFixed(1)
      document.getElementById('m-avg').textContent=avg
      document.getElementById('m-cnt').textContent=S.moods.length
      const r=S.moods.slice(-3).reduce((a,m)=>a+m.score,0)/Math.min(3,S.moods.length)
      const o=S.moods.length>3?S.moods.slice(-6,-3).reduce((a,m)=>a+m.score,0)/Math.min(3,S.moods.slice(-6,-3).length):r
      document.getElementById('m-trend').textContent=r>o+.5?'↑':r<o-.5?'↓':'→'
    }
    if(labels.length) document.getElementById('ch-s').textContent=labels[0]
    if(S.moods.length){
      const h=document.getElementById('mood-hist'); h.style.display='block'
      const l=document.getElementById('mood-hist-list'); l.innerHTML=''
      S.moods.slice().reverse().slice(0,5).forEach(m=>{
        const r=document.createElement('div')
        r.style.cssText='display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-bottom:1px solid var(--b1)'
        r.innerHTML=`<div style="display:flex;align-items:center;gap:10px"><span style="font-size:20px">${m.emoji}</span><div><div style="font-size:13px;color:var(--s3)">${m.label}</div><div style="font-size:10px;color:var(--s0);font-family:var(--fm)">${new Date(m.ts).toLocaleString()}</div></div></div><span style="font-family:var(--fm);font-size:12px;color:var(--s1)">${m.score}/10</span>`
        l.appendChild(r)
      })
    }
  },
}

// ═══════════════════════════════════════════
// JOURNAL
// ═══════════════════════════════════════════
const JOURNAL = {
  newPrompt() {
    document.getElementById('prom-txt').textContent = S.PROMPTS[~~(Math.random()*S.PROMPTS.length)]
  },
  type(el) {
    const w = el.value.trim().split(/\s+/).filter(Boolean).length
    document.getElementById('wc').textContent = `${w} words`
    document.getElementById('save-btn').disabled = w < 5
    if(el.value){ document.getElementById('enc-live').style.display='flex'; document.getElementById('enc-inline').style.display='flex' }
  },
  async save() {
    const text = document.getElementById('jta').value.trim()
    if(text.split(/\s+/).filter(Boolean).length < 5) return
    document.getElementById('save-btn').textContent = 'Encrypting...'
    document.getElementById('save-btn').disabled = true
    await encFlash(text)
    const entry = {id:Date.now(), content:text, words:text.split(/\s+/).filter(Boolean).length, ts:Date.now(), insight:null}
    // AI insight (non-blocking)
    if(Cfg.hasApiKey()) getInsight(text).then(i=>{if(i){entry.insight=i;saveVault()}}).catch(()=>{})
    S.entries.push(entry); S.journaledToday=true
    // Streak
    const today=new Date().toDateString(), yday=new Date(Date.now()-86400000).toDateString()
    if(S.entries.length===1){S.streak=1}
    else{const prev=S.entries.slice(-2)[0];const pd=new Date(prev.ts).toDateString();if(pd===yday)S.streak++;else if(pd!==today)S.streak=1}
    S.bestStreak=Math.max(S.bestStreak,S.streak)
    document.getElementById('sk-n').textContent=S.streak
    document.getElementById('sk-best').textContent=`best: ${S.bestStreak} days`
    APP.updReward()
    // Rewards
    let earned=10
    if(S.streak>=30) earned+=300
    else if(S.streak>=7) earned+=75
    else if(S.streak>=3) earned+=25
    await REWARDS.earn('journal', earned)
    // On-chain claim
    if(isConnected()){
      claimOnChain('journal').then(h=>{if(h) toast(`On-chain tx: ${h.slice(0,10)}…`)}).catch(()=>{})
      if(S.streak===3) claimOnChain('streak_3').catch(()=>{})
      if(S.streak===7) claimOnChain('streak_7').catch(()=>{})
      if(S.streak===30) claimOnChain('streak_30').catch(()=>{})
    }
    await saveVault(); this.renderHistory()
    toast(`Entry saved · +${earned} NOET ◈`)
    document.getElementById('write-card').innerHTML=`<div style="padding:22px;text-align:center"><div style="font-size:34px;margin-bottom:10px">✅</div><div style="font-size:14px;color:var(--s2)">Entry encrypted & saved 💜</div><div style="font-size:11px;color:var(--s0);margin-top:4px;font-family:var(--fm)">+${earned} NOET · ${S.streak} day streak 🔥</div></div>`
  },
  renderHistory() {
    if(!S.entries.length) return
    document.getElementById('past-wrap').style.display='block'
    const c=document.getElementById('past-list'); c.innerHTML=''
    S.entries.slice().reverse().forEach(e=>{
      const d=document.createElement('div'); d.className='ei'; d.onclick=()=>this.openEntry(e)
      d.innerHTML=`<div class="edate">${new Date(e.ts).toLocaleDateString('en',{weekday:'long',month:'long',day:'numeric',year:'numeric'})}</div><div class="eprev">${e.content}</div><div class="echips"><span class="chip">${e.words} words</span>${e.insight?'<span class="chip t">✦ insight</span>':''}<span class="chip t">⬡ encrypted</span></div>`
      c.appendChild(d)
    })
  },
  openEntry(e) {
    document.getElementById('ov-e-d').textContent=new Date(e.ts).toLocaleDateString('en',{weekday:'long',month:'long',day:'numeric'})
    document.getElementById('ov-e-b').textContent=e.content
    const ins=document.getElementById('ov-e-i')
    if(e.insight){ins.style.display='block';ins.innerHTML=`<span style="color:var(--teal);font-family:var(--fm);font-size:9px;letter-spacing:.1em;text-transform:uppercase">✦ Neural Insight</span><br><br>${e.insight}`}
    else ins.style.display='none'
    UI.showOv('ov-entry')
  },
}

// ═══════════════════════════════════════════
// REWARDS
// ═══════════════════════════════════════════
const TX_LABELS = {journal:'Journal Entry',mood:'Mood Check-in',first:'First Session',streak_3:'3-Day Streak',streak_7:'7-Day Streak',streak_30:'30-Day Legend'}
const REWARDS = {
  async earn(type, amount) {
    S.noet += amount; S.totalEarned += amount
    S.transactions.unshift({type, amount, hash:mockTxHash(), ts:Date.now(), onchain:false})
    APP.updateBal()
  },
  renderTx() {
    const c=document.getElementById('tx-list')
    if(!S.transactions.length){c.innerHTML='<div style="padding:16px;text-align:center;font-size:12px;color:var(--s0)">No rewards yet — start journaling 💜</div>';return}
    c.innerHTML=''
    S.transactions.slice(0,10).forEach(tx=>{
      const r=document.createElement('div'); r.className='tx'
      r.innerHTML=`<div class="txl"><div class="txd"></div><div><div class="txn">${TX_LABELS[tx.type]||'Reward'}</div><div class="txh">${tx.hash.slice(0,14)}…</div></div></div><div class="txa ${tx.onchain?'chain':''}">${tx.onchain?'⛓ ':'+'}${tx.amount} NOET</div>`
      c.appendChild(r)
    })
  },
  renderMilestones() {
    const miles=[
      {lbl:'First Entry',  ico:'✍', n:10,  done:S.entries.length>=1,       d:'Write your first journal'},
      {lbl:'3-Day Streak', ico:'🔥', n:25,  done:S.streak>=3,              d:'Journal 3 days in a row'},
      {lbl:'7-Day Streak', ico:'⚡', n:75,  done:S.streak>=7,              d:'One full week'},
      {lbl:'Mood Pioneer', ico:'📊', n:5,   done:S.moods.length>=1,        d:'Log your first mood'},
      {lbl:'Deep Mind',    ico:'💬', n:50,  done:S.uMsgs>=10,              d:'10 conversations'},
      {lbl:'30-Day Legend',ico:'👑', n:300, done:S.streak>=30,             d:'Ultimate commitment'},
    ]
    const g=document.getElementById('mile-grid'); g.innerHTML=''
    miles.forEach(m=>{
      const c=document.createElement('div'); c.className=`mc ${m.done?'done':''}`
      c.innerHTML=`<div class="mci">${m.ico}</div><div class="mcn">${m.lbl}</div><div class="mcd">${m.d}</div><div class="mct">+${m.n} NOET</div>${m.done?'<div class="mck2">◈ achieved</div>':''}`
      g.appendChild(c)
    })
  },
}

// ═══════════════════════════════════════════
// BOOT
// ═══════════════════════════════════════════
mount()
initCanvas()

// expose to inline onclick handlers
Object.assign(window, { UI, ONB, APP, CHAT, MOOD, JOURNAL, REWARDS })

// Wallet change listener
window.addEventListener('wallet:changed', e => {
  if (e.detail.address) {
    document.getElementById('chat-gate').style.display = 'none'
  }
})
